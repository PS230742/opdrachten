<?php
//header("access-control-allow-credentials: false");
//header('access-control-allow-methods: GET,POST,PUT');
header('access-control-allow-origin: *');
header('content-type: application/json');
echo file_get_contents('https://www.rijdendetreinen.nl/feed.json');
