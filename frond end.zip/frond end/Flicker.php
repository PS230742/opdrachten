<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

echo file_get_contents('https://api.flickr.com/services/feeds/photos_public.gne?format=json&tagmode=any&nojsoncallback=1&'.$_SERVER['QUERY_STRING']);
